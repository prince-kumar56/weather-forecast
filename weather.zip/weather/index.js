let city_name = document.querySelector(".search-box input");
let search = document.querySelector("#btn");
let temp = document.querySelector(".temperature");
let condition = document.querySelector(".description");
let humidityPercentage = document.querySelector(".info-humidity span");
let windSpeed = document.querySelector(".info-wind span");
let image = document.querySelector(".weather img");
const API_key = '7ad9dff54b6048dd3bb4bfc87dd0441f';
async function checkWeather(city_name){
const APIurl = `https://api.openweathermap.org/data/2.5/weather?q=${city_name}&appid=${API_key}`;
const response = await fetch(APIurl);
let data= await response.json();
console.log(data);
temp.innerText=Math.round(data.main.temp-273.15) + "°C";
condition.innerText=data.weather[0].main;
humidityPercentage.innerText=data.main.humidity + "%";
windSpeed.innerText=data.wind.speed + "km/h";
image.src = `assets/${data.weather[0].main}.png`;
}
search.addEventListener("click",()=>{
checkWeather(city_name.value.trim().toLowerCase());
});